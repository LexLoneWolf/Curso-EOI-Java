/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2703;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class Binarios {

    public void convertirBinarioDecimal() {

        String numerobinario = "";
        int numerodecimal = 0;

        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el número binario a convertir: ");
        numerobinario = sc.next();

        // De izq a derecha
        for (int i = 0; i < numerobinario.length(); i++) {
            if (numerobinario.charAt(i) == '1') {
                numerodecimal += Math.pow(2, numerobinario.length()-1-i);
            }
        }
        
        System.out.println(numerodecimal);
        
        // De Derecha a izq
        /*for (int i = numerobinario.length()-1; i >= 0; i--) {
            if (numerobinario.charAt(i) == '1') {
                numerodecimal += Math.pow(2,numerobinario.length()-i-1);
            }
        }*/

    }

}
