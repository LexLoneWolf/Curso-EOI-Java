/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2703;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class EjerciciosArrayList {

    public void ejemplo1() {

        ArrayList lista = new ArrayList();  // Crear el ArrayList
        ArrayList listacopia = new ArrayList();

        // Meter valores
        lista.add(1);
        lista.add("Fran");
        lista.add(10.14);
        lista.add("Dani");
        lista.add(2,"Naiara");  // Inserta en la posición 3 de la lista
        lista.remove(3);    // borra el 4 elemento
        lista.remove(lista.size()-1);   // borra el último elemento de una lista
        lista.remove(0);
        //lista.remove(2);   Esto daría error
        lista.clear();      // limpia la lista
        String cadena = "Fran";
        lista.add(cadena.toLowerCase());
        lista.add("Nourredine".toUpperCase()); // NOURREDINE
        lista.add("JAVIER".toLowerCase());  // javier
        lista.add("Bárbara");
        lista.set(1, "Javi");   // Sustituye la posición 2 por Javi
        lista.add("Javi");
        System.out.println("El primer Javi está en la posición " + lista.indexOf("Javi"));
        
        
        listacopia = (ArrayList) lista.clone(); // Copia una lista en otra
        System.out.println(listacopia);         // ¿Imprime la lista? Sí, en otro formato
        
        if(lista.contains("Fran") && lista.contains("fran")){     // Ver si un elemento está en la lista
            System.out.println("La lista tiene a Fran");
        }
        else{
            System.out.println("La lista no tiene a Fran");
        }
        
        // Esta linea hace lo mismo que las 5 anteriores
        System.out.println((lista.contains("Fran") && lista.contains("fran"))?"La lista tiene a Fran":"La lista no tiene a Fran");
        //(condicion1 && condicion2)?verdad:pregunta2?verdad2:falso;
        
        // recorrer un ArrayList con un for
        /*for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }*/
        
        // recorrer con elementos Object con forEach
        for(Object elemento : lista){
            System.out.println(elemento);
            
        }
   }
    
    
    public void ejemplo2(){
        ArrayList<String> alumnos = new ArrayList<String>();
        
        alumnos.add("Nourredine");
        alumnos.add("Angélica");
        alumnos.add("Naiara");
        alumnos.add("Julio");
        
        System.out.println(alumnos);    // Imprime todos los alumnos de la lista
        for(String alumno : alumnos){
            System.out.println(alumno.toUpperCase() + " " + alumno.toLowerCase() + " " +  alumno.substring(0, 3));
        }       
    }

}
