/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clase2703;

import java.util.ArrayList;

/**
 *
 * @author Profesor
 */
public class Clase2703 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Binarios b = new Binarios();
        EjerciciosArrayList e = new EjerciciosArrayList();
        
        // ArrayList de Personas
        ArrayList<Persona> alumnos = new ArrayList<>();
        
        // Personas
        Persona angelica = new Persona("Angélica","Amrós","Fructuoso","1234");
        Persona naiara = new Persona("Naiara","","","");
        Persona nourredine = new Persona("Nourredine", "","", "5678");
        Persona barbara = new Persona();
        Persona julio = new Persona("Julio","Herrera","Seara");
        Persona javi = new Persona("Javi",22);
        
        // Añadir Personas al ArrayList de Alumnos
        alumnos.add(angelica);
        alumnos.add(javi);
        alumnos.add(naiara);
        
        for(Persona alumno: alumnos){
            System.out.println(alumno.getNombre() + " " + alumno.getApellido1());
            //System.out.println(alumno.getNombre() + " " + (alumno.getApellido1()==null?"":alumno.getApellido1()));
        }
        
        //b.convertirBinarioDecimal();
        //e.ejemplo1();
        //e.ejemplo2();
        //System.out.println(angelica.getNombre());
        //angelica.setApellido1("Amorós");
        //System.out.println(angelica.getApellido1());
       
    }

}
