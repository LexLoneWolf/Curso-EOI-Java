package com.dam.profesor.holamundoeoi;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button boton;   // Paso 1. Crear la variable
    EditText texto;
    String cadena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boton = findViewById(R.id.button2); // Paso 2. Me enlazo con el botón del diseño
        texto = findViewById(R.id.editText);


        // Paso 3. Controlar el click del boton
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Ventana2.class);

                // Pasar datos entre ventanas
                Bundle b = new Bundle();
                cadena = texto.getText().toString();
                b.putString("NOMBRE", cadena);
                b.putString("Fran","Hola me llamo fran");
                intent.putExtras(b);

                startActivity(intent);
            }
        });

    }
}
