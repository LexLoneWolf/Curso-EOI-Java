package com.dam.profesor.holamundoeoi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Ventana2 extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana2);

        textView = findViewById(R.id.textView);
        Bundle b = this.getIntent().getExtras();
        textView.setText("Hola " + b.getString("NOMBRE"));

    }
}
