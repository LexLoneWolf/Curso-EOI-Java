/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase0404file;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Profesor
 */
public class Clase0404File {

    static String ruta = "C:\\Users\\Profesor\\Documents";
    static String nombrefichero = "empleados.csv";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        // Ejemplo de ruta relativa
        /*File f1 = new File("empleados.csv");
        if(f1.exists()){
            System.out.println("El fichero existe");
        }
        else{
            System.out.println("El fichero no existe");
        }
        
        // ruta relativa dentro del proyecto
        File f2 = new File("ficheros/empleados/empleados.csv");
        if(f2.exists()){
            System.out.println("El fichero existe");
        }
        else{
            System.out.println("El fichero no existe");
        }
        
        // ruta absoluta
        File f3 = new File("C:\\Users\\Profesor\\Documents/empleados.csv");
        if(f3.exists()){
            System.out.println("El fichero existe");
        }
        else{
            System.out.println("El fichero no existe");
        }*/
        // ruta absoluta con 2 parámetros
        /*File f4 = new File(ruta,nombrefichero);
        //File f5 = new File(ruta,nombrefichero+ "fran");
        if(f4.exists()){
            System.out.println("La longitud del fichero es: " + f4.length());
            //f4.renameTo(f5);
           
        }
        else{
            System.out.println("El fichero no existe");
        }*/
        
        // Crea un fichero desde cero y le mete datos
        /*try {
            // Escribir en un fichero
            FileWriter fw = new FileWriter("C:\\Users\\Profesor\\Documents\\prueba0404.txt");
            System.out.println("Si he podido crear el fichero");
            PrintWriter salida = new PrintWriter(fw);
            salida.println("añade esto");
            salida.close();
        } catch (IOException ex) {
            System.out.println("No he podido crear el fichero");
        }*/

        
        /* Para añadir en un fichero que ya existe */
        
        File file = new File("C:\\Users\\Profesor\\Documents\\prueba0404.txt");
        FileWriter fr = new FileWriter(file, true);
        BufferedWriter br = new BufferedWriter(fr); // memoria provisional
        br.write("linea añadida");  // lo añado al fichero

        br.close();
        fr.close();

    }

}
