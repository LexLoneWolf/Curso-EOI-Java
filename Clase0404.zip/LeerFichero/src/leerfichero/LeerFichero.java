/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leerfichero;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Profesor
 */
public class LeerFichero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        StringBuilder sb = new StringBuilder();
        
        try {
            FileReader fr = new FileReader("C:\\Users\\Profesor\\Documents\\empleados.csv");
            
            BufferedReader br = new BufferedReader(fr);
            String linea;
            int contadorlineas=0;
            int sumasalarios=0;
            int salariomaximo=Integer.MIN_VALUE;
            int salariominimo=Integer.MAX_VALUE;
            String nombreempleadosalariomaximo="";
            String nombreempleadosalariominimo="";
            while((linea = br.readLine()) != null){ // Mientras haya lineas que coger
                // Aquí recorro el fichero linea a linea
                contadorlineas++;
                if(contadorlineas!=1){  // Con esto me quito la linea de la cabecera
                    sb.setLength(0);
                    sb.append(linea);
                    String nombreempleadoactual = sb.substring(0,sb.indexOf(";"));
                    int salarioempleadoactual = Integer.parseInt(sb.substring(sb.lastIndexOf(";")+1));
                    sumasalarios += salarioempleadoactual;
                    if(salarioempleadoactual>salariomaximo){
                        nombreempleadosalariomaximo = nombreempleadoactual;
                        salariomaximo = salarioempleadoactual;
                    }
                    if(salarioempleadoactual<salariominimo){
                        nombreempleadosalariominimo = nombreempleadoactual;
                        salariominimo = salarioempleadoactual;
                    }
                }
            }
            
            System.out.println("El salario medio es: " + ((double)sumasalarios/(contadorlineas-1)));
            System.out.println("El empleado que más gana es " + nombreempleadosalariomaximo + " y gana " + salariomaximo);
            System.out.println("El empleado que menos gana es " + nombreempleadosalariominimo + " y gana " + salariominimo);

            fr.close();
                
        } catch (FileNotFoundException ex) {
            System.out.println("No he podido abrir el fichero");
        } catch (IOException ex) {
            System.out.println("No puedo leer el fichero");
        }
   }
    
}
