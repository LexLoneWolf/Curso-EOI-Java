/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase0404;

/**
 *
 * @author Profesor
 */
public class Libro {

    private String titulo;
    private String autor;
    private int ejemplares;
    private int prestados;

    /**
     * Constructor por defecto. Pongo prestados a 0.
     */
    public Libro() {
        prestados = 0;
    }

    /**
     * Constructor con parámetros
     *
     * @param titulo - titulo del libro
     * @param autor
     * @param ejemplares - ejemplares que poseemos en la biblioteca
     * @param prestados
     */
    public Libro(String titulo, String autor, int ejemplares, int prestados) {
        this.titulo = titulo;
        this.autor = autor;
        this.ejemplares = ejemplares;
        this.prestados = 0;

    }

    /**
     * Constructor de copia
     *
     * @param libro - libro que quiero duplicar
     */
    public Libro(Libro libro) {
        this.titulo = libro.titulo;
        this.autor = libro.autor;
        this.ejemplares = libro.ejemplares;
        this.prestados = libro.prestados;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getEjemplares() {
        return ejemplares;
    }

    public void setEjemplares(int ejemplares) {
        this.ejemplares = ejemplares;
    }

    public int getPrestados() {
        return prestados;
    }

    public void setPrestados(int prestados) {

        this.prestados = prestados;

    }

    public boolean prestamo() {
        if (prestados < ejemplares) {
            prestados++;
            return true;
        } else {
            return false;
        }
    }

    public boolean devolucion() {
        if (prestados == 0) {
            return false;
        } else {
            prestados--;
            return true;
        }
    }

}
