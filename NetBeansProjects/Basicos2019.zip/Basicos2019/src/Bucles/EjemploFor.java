/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bucles;

/**
 *
 * @author Profesor
 */
public class EjemploFor {

    public static void main(String[] args) {
        /*for(int i=1;i<=20;i++){
            System.out.println("Hola"); // Esto imprime hola 20 veces
        }*/
        for(int i=100;i>=1;i--){
            System.out.println(i);
        }

        /*for (int tabla = 1; tabla <= 5; tabla++) {
            for (int i = 1; i <= 10; i++) {
                System.out.println(tabla + " * " + i + " = " + (tabla * i));
            }
        }*/

    }

}
