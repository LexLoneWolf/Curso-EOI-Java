/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liga;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author Profesor
 */
public class Liga {

    static Equipo barsa,madrid;
    static List<Jugador> jugadoresbarsa = new ArrayList<>();
    static List<Jugador> jugadoresmadrid = new ArrayList<>();
    static List<Equipo> equipos = new ArrayList<>();
    static List<Partido> partidos = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        crearJugadores();   // Me crea los jugadores y los mete en las listas de sus equipos
        crearEquipos(); // Crea los equipos
        crearPartidos();
        imprimirEquipos();
        victoriaslocalesvsvisitantes();
        partidosGanados("Barça");
        partidosGanados("Madrid");
        //jugadoresEquipoEmpiecenLetra("Madrid",'C');
    }

    /**
     * Crea jugadores y los mete en las listas de sus equipos
     */
    public static void crearJugadores() {
        Jugador j1 = new Jugador("Messi", 32, "Argentino");
        Jugador j2 = new Jugador("Cristiano", 34, "Portugués");
        Jugador j3 = new Jugador(j1);   // Clon de Messi
        Jugador j4 = new Jugador();
        j3.setNombre("Pique");
        j3.setNacionalidad("Español");
        j4.setNombre("Sergio Ramos");
        j4.setEdad(32);
        j4.setNacionalidad("Español");
        jugadoresbarsa.add(j1);
        jugadoresbarsa.add(j3);
        //jugadoresmadrid.add(j2);
        //jugadoresmadrid.add(j4);
        insertarJugadorEquipo(j2,jugadoresmadrid);
        insertarJugadorEquipo(j4,jugadoresmadrid);
    }
    
    public static void insertarJugadorEquipo(Jugador jugador, List<Jugador> equipo){
        equipo.add(jugador);
    }

    /**
     * Crea los equipos de la liga
     */
    public static void crearEquipos() {
        barsa = new Equipo("Barça", 1899, 100000, jugadoresbarsa);
        madrid = new Equipo("Madrid", 1901, 90000, jugadoresmadrid);
        equipos.add(barsa);
        equipos.add(madrid);
    }
    
    public static void crearPartidos(){
        Partido p1 = new Partido("Camp Nou",barsa,madrid,2,0);
        Partido p2 = new Partido("Camp Nou",barsa,madrid,0,2);
        Partido p3 = new Partido("Bernabeu",madrid,barsa,0,1);
        Partido p4 = new Partido("Bernabeu",madrid,barsa,1,4);
        partidos.add(p1);
        partidos.add(p2);
        partidos.add(p3);
        partidos.add(p4);        
    }
    
    public static void imprimirEquipos(){
        equipos.stream()
                .sorted(Comparator.comparing(Equipo::getAnyofundacion).reversed())
                .forEach(e->System.out.println(e.toString()));
    }
    
    public static void victoriaslocalesvsvisitantes(){
        long victoriaslocales = partidos.stream()
                .filter(e->e.getGoleslocal()>e.getGolesvisitante())
                .count();
        long victoriasvisitantes = partidos.stream()
                .filter(e->e.getGoleslocal()<e.getGolesvisitante())
                .count();
        System.out.println(victoriaslocales + " - " + victoriasvisitantes);
    }
    
    public static void partidosGanados(String nombreequipo){
        long victoriaslocales = partidos.stream()
                .filter(e->e.getLocal().getNombre().equals(nombreequipo)
                        && e.getGoleslocal()>e.getGolesvisitante())
                .count();

        long victoriasvisitantes = partidos.stream()
                .filter(e->e.getVisitante().getNombre().equals(nombreequipo)
                        && e.getGoleslocal()<e.getGolesvisitante())
                .count();
        int victorias = (int)(victoriaslocales+victoriasvisitantes);
        System.out.println("El " + nombreequipo + " ha ganado " + victorias + " partido" + (victorias!=1?"s":""));
            // El Barsa ha ganado 7 partidos
    }
    
    public static void jugadoresEquipoEmpiecenLetra(String equipo, char letra){
        List<Jugador> jugadoresequipo;
        jugadoresequipo = (List)equipos.stream()
                .filter(e->e.getNombre().equals(equipo)) // Equipo que me pasan
                .map(Equipo::getPlantilla)
                .collect(Collectors.toList());
        
        for(Jugador jugador : jugadoresequipo){
            if(jugador.getNombre().charAt(0)==letra){
                System.out.println(jugador.getNombre());
            }
        }
        /*jugadoresequipo.stream()
                .map(Jugador::getNombre)
                .filter(j->j.charAt(0)==letra)
                .forEach(j->System.out.println(j));*/
        //System.out.println(jugadoresequipo.toString());
                
                
    }
    
}
