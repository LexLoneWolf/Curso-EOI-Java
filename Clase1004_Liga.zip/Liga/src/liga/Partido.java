/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liga;

/**
 *
 * @author Profesor
 */
public class Partido {
    
    private String estadio;
    private Equipo local;
    private Equipo visitante;
    private int goleslocal;
    private int golesvisitante;
    static int contadorpartidos;    // variable global para todos los partidos
    final int NUMEROEQUIPOS=2;       // constante que no se puede cambiar
    
    public Partido(){
        contadorpartidos++;
    }

    public Partido(String estadio, Equipo local, Equipo visitante, int goleslocal, int golesvisitante) {
        this.estadio = estadio;
        this.local = local;
        this.visitante = visitante;
        this.goleslocal = goleslocal;
        this.golesvisitante = golesvisitante;
        contadorpartidos++;
    }
    
    public Partido (Partido p){
        this.estadio = p.estadio;
        this.local = p.local;
        this.visitante = p.visitante;
        this.goleslocal = p.goleslocal;
        this.golesvisitante = p.golesvisitante;
        contadorpartidos++;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public Equipo getLocal() {
        return local;
    }

    public void setLocal(Equipo local) {
        this.local = local;
    }

    public Equipo getVisitante() {
        return visitante;
    }

    public void setVisitante(Equipo visitante) {
        this.visitante = visitante;
    }

    public int getGoleslocal() {
        return goleslocal;
    }

    public void setGoleslocal(int goleslocal) {
        this.goleslocal = goleslocal;
    }

    public int getGolesvisitante() {
        return golesvisitante;
    }

    public void setGolesvisitante(int golesvisitante) {
        this.golesvisitante = golesvisitante;
    }

    public static int getContadorpartidos() {
        return contadorpartidos;
    }

    public static void setContadorpartidos(int contadorpartidos) {
        Partido.contadorpartidos = contadorpartidos;
    }
    
    

    @Override
    public String toString() {
        return local + " " + goleslocal + " - " + visitante + " " + golesvisitante;
    }
    
    
    
}
