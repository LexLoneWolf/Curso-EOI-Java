/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liga;

/**
 *
 * @author Profesor
 */
public class Jugador {
    
    private String nombre;
    private int edad;
    private String nacionalidad;
    
    /**
     * Constructor vacio
     */
    public Jugador(){
        
    }

    /**
     * Constructor con parametros
     * @param nombre
     * @param edad
     * @param nacionalidad 
     */
    public Jugador(String nombre, int edad, String nacionalidad) {
        this.nombre = nombre;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
    }
    
    /**
     * Constructor de copia
     * @param j 
     */
    public Jugador(Jugador j){
        this.nombre = j.nombre;
        this.edad = j.edad;
        this.nacionalidad = j.nacionalidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad ;
    }
    
    
    
}
