/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liga;

import java.util.List;

/**
 * Esta clase guardara el equipo que luego usaremos en los partidos
 * v1.0
 * modificado por Fran 10/04/2019
 * @author Fran
 */
public class Equipo {
    
    private String nombre;
    private int anyofundacion;
    private int numerosocios;
    List<Jugador> plantilla;
    
    public Equipo(){
        
    }

    public Equipo(String nombre, int anyofundacion, int numerosocios, List<Jugador> plantilla) {
        this.nombre = nombre;
        this.anyofundacion = anyofundacion;
        this.numerosocios = numerosocios;
        this.plantilla = plantilla;
    }
    
    public Equipo(Equipo e){
        this.nombre = e.nombre;
        this.anyofundacion = e.anyofundacion;
        this.numerosocios = e.numerosocios;
        this.plantilla = e.plantilla;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAnyofundacion() {
        return anyofundacion;
    }

    public void setAnyofundacion(int anyofundacion) {
        this.anyofundacion = anyofundacion;
    }

    public int getNumerosocios() {
        return numerosocios;
    }

    public void setNumerosocios(int numerosocios) {
        this.numerosocios = numerosocios;
    }

    public List<Jugador> getPlantilla() {
        return plantilla;
    }

    public void setPlantilla(List<Jugador> plantilla) {
        this.plantilla = plantilla;
    }

    @Override
    public String toString() {
        return nombre + " año de fundación " + anyofundacion;
    }

    /*@Override
    public String toString() {
        return "Nombre: " + nombre + "\nFundación: " + anyofundacion + "\nSocios: " + numerosocios + "\nPlantilla \n" + plantilla;
    }*/
    
    
    
}
