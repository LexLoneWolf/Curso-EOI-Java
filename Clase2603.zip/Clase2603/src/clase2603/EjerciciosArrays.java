/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2603;

import java.util.Scanner;

/**
 *
 * @author Profesor
 */
public class EjerciciosArrays {
    
    public void ejercicio2(){
        
        int []numeros = new int[10];    // Elementos del array
        int suma=0;                     // Suma acumulada
        int contadorpares = 0, contadorimpares= 0;
        
        
        Scanner sc = new Scanner(System.in);
        
        // Lee 10 números por pantalla y los asigna a la posición correspondiente
        for (int i = 0; i < 10; i++) {
            System.out.println("Introduzca un número: ");
            numeros[i]=sc.nextInt();
        }
        
        // bucle que calcula la suma de los números pares
        for (int i = 0; i < 10; i++) {
            if(i%2==0){ // Los pares
                suma += numeros[i];
                contadorpares++;
            }
            else{   // Los impares
                //suma += numeros[i];
                //contadorimpares++;
            }
        }
        
        System.out.println(suma/contadorpares);
        
        
    }
    
    public void ejercicio3(){
        
        Scanner sc = new Scanner(System.in);
        int numalumnos=0;
        int sumanotas=0;
        double media = 0;
        
        // Obtengo el número de alumnos
        System.out.println("Introduce el número de alumnos:");
        numalumnos = sc.nextInt();
        // ceclaro el array de nombres y el de notas
        String []nombrealumnos = new String[numalumnos];
        int []notaalumnos = new int [numalumnos];
        
        // Lee por pantalla los nombres y notas y los asigna a la posición correspondiente
        for (int i = 0; i < numalumnos; i++) {
            System.out.println("Introduzca el nombre del alumno " + i + ":");
            nombrealumnos[i]= sc.next();
            System.out.println("Introduzca la nota del alumno " + i + ":");
            notaalumnos[i]=sc.nextInt();
            sumanotas += notaalumnos[i];
        }
        
        media = sumanotas/numalumnos;
        System.out.println("La nota media es: " + media);
        
        System.out.println("Los siguientes alumnos tienen una nota superior a la media:");
        for (int i = 0; i < numalumnos; i++) {
            if(notaalumnos[i]>media){
            }
        }
        
        
        
    }
    
    
}
