/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2603;

import java.util.Arrays;

/**
 *
 * @author Profesor
 */
public class Ejercicios {

    public void ejemplosPrintf() {
        double numero, numeronegativo;
        int numeroentero;

        numero = 10145.45678;
        numeronegativo = -10.45678;
        numeroentero = 10;

        System.out.println(numero);
        System.out.printf("%.2f \n", numero);
        System.out.printf("%+.2f %n", numero);
        System.out.printf("%+.2f %n", numeronegativo);
        System.out.printf("%d \n", numeroentero);
        System.out.printf("%d %+.2f \n", numeroentero, numeronegativo);
        System.out.printf("%d \n", numeroentero);
        System.out.printf("%d€ \n", numeroentero);
        System.out.printf("%+10.2f %n", numeronegativo);
        System.out.printf("%+10.2f %n", numero);
        System.out.printf("%+010.2f %n", numeronegativo);
        System.out.printf("%+010.2f %n", numero);
    }

    public void ejemplosArrays() {
        int numero;
        int[] conjuntonumeros;  // Forma primera de declarar un array
        int conjuntonumeros2[] = new int[10]; // Forma segunda de declarar un array
        numero = 10;
        int resultado = 0;

        conjuntonumeros = new int[10];

        // Acceder a los elementos de un array
        conjuntonumeros[0] = 12;
        conjuntonumeros[1] = 10;
        conjuntonumeros[2] = 1234;

        conjuntonumeros[9] = 12121;
        conjuntonumeros[4] = conjuntonumeros[1];
        conjuntonumeros[1] = 100000;
        //conjuntonumeros[10]= 15; Fallo típico
        for (int i = 0; i < 10; i++) {  // Recorre los 10 primeros elementos del array
            System.out.println(conjuntonumeros[i]);
        }
        for (int i = 0; i < conjuntonumeros.length; i++) {  // recorre todo el array
            System.out.println(conjuntonumeros[i]); // imprime
        }
        for (int i = 0; i < conjuntonumeros.length; i++) {
            resultado += conjuntonumeros[i];  // Suma todos los elementos del array y los guarda en resultado
        }
        System.out.println(resultado);  // imprime el resultado de la suma

    }

    public double mediaNotas() { // Devolverá la nota media de un curso
        double[] notas = {4.5, 6.3, 7.2, 9, 5, 4.8, 1, 3};
        double total = 0;
        for (int i = 0; i < notas.length; i++) {
            total += notas[i];
        }
        return (total / notas.length);

    }

    public void ejemploForEach() {
        String[] alumnos = {"Angélica", "Carlos", "Ricardo", "Alexis", "Eduardo"};

        for (String alumno : alumnos) {
            System.out.println(alumno);
        }

    }

    public void ejemploMatrices() {

        final int FILAS = 3, COLUMNAS = 4;
        final double PI = 3.14159;

        //PI = 2; Esto provoca error
        int[][] matriz = new int[4][5]; // Matriz cuadrada
        int[][] matrizconstantes = new int[FILAS][COLUMNAS];

        int totalmatriz = 0;
        for (int i = 0; i < FILAS; i++) {
            // Se hace antes de las casillas de la fila
            System.out.println("Inicio de la fila " + i);
            for (int j = 0; j < COLUMNAS; j++) {
                totalmatriz += matrizconstantes[i][j];
                System.out.println("Elemento[" + i + "][" + j + "] = " + matrizconstantes[i][j]);
            }
            // Se hace después de las casillas de la fila
            System.out.println("Final de la fila " + i);

        }

        int[][] matrizirregular = new int[3][];    // Matriz irregular de 3 filas
        matrizirregular[0] = new int[10];
        matrizirregular[1] = new int[15];
        matrizirregular[2] = new int[20];

        int[][] matriz3 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        matriz[1][2] = 5;    // le asigno el valor al 3 elemento de la segunada fila
        int resultado = matriz3[1][1] + matriz3[2][1];   // 5 + 8
        //int resultado2 = matriz3[1][3] + matriz3[2][1]; Esto falla por el 3

        // Como recorrer una matriz independientemente de sus filas y columnas
        for (int x = 0; x < matriz3.length; x++) {
            for (int y = 0; y < matriz3[x].length; y++) {
                System.out.println(matriz3[x][y]);
            }
        }

    }

    public void crearMatrizConIva(){
        final double IVA = 1.21;
        final int FILAS = 10;
        final int COLUMNAS = 5;
        double [][] preciossiniva = new double[FILAS][COLUMNAS]; // Declaro y reservo memoria
        double [][] preciosconiva = new double[FILAS][COLUMNAS];
        
        // Asigno valores
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                preciossiniva[i][j] = Math.random()*1000;
                preciosconiva[i][j] = preciossiniva[i][j] * IVA;
                //System.out.println("Elemento[" + i + "][" + j + "] = " + preciossiniva[i][j]);
            }           
        } 

        
        
    }
    
    public void ejemploClaseArrays(){
        int []array1 = {1,3,3,4};
        int []array2 = {1,2,3,4};
        int []array3;
        String []alumnos = {"Amorós", "Ivanov", "Candela", "Ramírez", "Braganza"};
        
        // Ordena de menor a mayor
        Arrays.sort(alumnos);   // Ordena lo que tu le pases
        for(String alumno : alumnos){
            System.out.println(alumno);
        }
        
        //Comparar dos arrays
        if(Arrays.equals(array1, array2)){
            System.out.println("Son iguales");
        }
        else{
            System.out.println("No son iguales");
        }
        
        array3 = Arrays.copyOf(array1, array1.length);  // Copia en array3 lo que tiene array1
        if(Arrays.equals(array1, array3)){
            System.out.println("Son iguales");
        }
        else{
            System.out.println("No son iguales");
        }
        
    }
    
}
