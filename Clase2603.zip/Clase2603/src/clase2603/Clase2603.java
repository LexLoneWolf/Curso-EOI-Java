/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase2603;

/**
 *
 * @author Profesor
 */
public class Clase2603 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Ejercicios e = new Ejercicios();
        EjerciciosArrays ea = new EjerciciosArrays();
        //e.ejemplosPrintf();
        //e.ejemplosArrays();
        //System.out.printf("%+.2f",e.mediaNotas());
        //e.ejemploForEach();
        //e.ejemploMatrices();
        //e.crearMatrizConIva();
        //e.ejemploClaseArrays();
        //ea.ejercicio2();
        ea.ejercicio3();
    }
    
}
