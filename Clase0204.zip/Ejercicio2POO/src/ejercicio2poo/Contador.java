/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2poo;

/**
 *
 * @author Profesor
 */
public class Contador {
    
    // Atributos
    private int cont;
    
    // Contador por defecto
    public Contador(){
        
    }
    // Constructor con parámetros
    public Contador(int cont){
        this.cont = cont;
        if(cont<0){
            this.cont=0;
        }              
    }
    
    public Contador(Contador contador){
        this.cont = contador.cont;
    }

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }
    
    public void incrementar(){
        this.cont++;
    }
    
    // Función que incrementa un número de unidades pasada por parámetro
    public void incrementar(int incremento){
        if(incremento>0){
            this.cont += incremento;
        }
    }
    
    public void decrementar(){
        this.cont--;
        if(this.cont<0){
            this.cont = 0;
        }
    }
    
    public void decrementar(int decremento){
        this.cont -= decremento;
        if(this.cont<0){
            this.cont = 0;
        }
    }
    
}
