/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1poo;

/**
 *
 * @author Profesor
 */
public class Cuenta {
    
    protected String nombre_cliente, numero_cuenta;
    private double tipo_interes, saldo;
    
    // Constructores
    public Cuenta(){
        
    }

    public Cuenta(String nombre_cliente, String numero_cuenta, double tipo_interes, double saldo) {
        this.nombre_cliente = nombre_cliente;
        this.numero_cuenta = numero_cuenta;
        this.tipo_interes = tipo_interes;
        this.saldo = saldo;
    }
    
    // Constructor de copia
    public Cuenta (Cuenta cuenta){
        this.nombre_cliente = cuenta.getNombre_cliente();
        this.numero_cuenta = cuenta.getNumero_cuenta();
        this.tipo_interes = cuenta.getTipo_interes();
        this.saldo = cuenta.getSaldo();
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public String getNumero_cuenta() {
        return numero_cuenta;
    }

    public void setNumero_cuenta(String numero_cuenta) {
        this.numero_cuenta = numero_cuenta;
    }

    public double getTipo_interes() {
        return tipo_interes;
    }

    public void setTipo_interes(double tipo_interes) {
        this.tipo_interes = tipo_interes;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nDatos de la cuenta");
        sb.append("\nNombre del titular: ").append(this.getNombre_cliente());
        sb.append("\nNúmero de cuenta: " + this.getNumero_cuenta());
        sb.append("\nTipo de interés: " + this.getTipo_interes());
        sb.append("\nSaldo: ").append(this.getSaldo());
        sb.append("\n-------------------------------");
        return sb.toString();
    }
    
    public boolean ingreso(double cantidad){
        if(cantidad<0){
            return false;
        }
        saldo += cantidad;
        return true;
    }
    
    public boolean reintegro (double cantidad){
        if(cantidad<0){
            return false;
        }
        if(cantidad>saldo){
            return false;
        }
        saldo -=cantidad;
        return true;
    }
    
    public boolean reintegro2 (double cantidad){
        if(cantidad<0 || cantidad>saldo){
            return false;
        }
        saldo -=cantidad;
        return true;
    }
    
    public boolean reintegro3 (double cantidad){
        if(cantidad>0 && cantidad<=saldo){
            saldo -=cantidad;
            return true;
        }
        return false;
        
    }
    
    public boolean reintegro4 (double cantidad){
        if(cantidad<0){
            return false;
        }
        else if(cantidad>saldo){
            return false;
        }
        else{
            saldo -=cantidad;
            return true;
        }
    }
    
    // Esta versión no me gusta porque accedemos directamente
    // al saldo de otra cosa sin utilizar sus funciones
    public boolean transferencia(Cuenta cuentadestino,double importe){
        if(saldo>=importe){
            saldo -=importe;    // quitar dinero a la cuenta original
            cuentadestino.saldo += importe; // Le añade el dinero a la otra cuenta
            return true;
        }
        else{
            return false;
        }
        
    }
    
    // utilizamos las funciones de la cuenta destino, pero tampoco me gusta
    // porque no estamos haciendo uso del ingreso y reintegro
    public boolean transferencia1(Cuenta cuentadestino,double importe){
        if(saldo>=importe){
            saldo -=importe;    // quitar dinero a la cuenta original
            cuentadestino.setSaldo(cuentadestino.getSaldo()+importe); // Le añade el dinero a la otra cuenta
            return true;
        }
        else{
            return false;
        }
        
    }
    
    // Esta es la buena.
    public boolean transferencia2(Cuenta cuentadestino,double importe){
        if(this.reintegro(importe)){
            cuentadestino.ingreso(importe);
            return true;
        }
        return false;        
    }
    
    // Incorrecto porque no compruebo que me han quitado el dinero
    public boolean transferencia3(Cuenta cuentadestino,double importe){
        this.reintegro(importe);            
        cuentadestino.ingreso(importe);
        return true;
     
    }
     
    
    
    
}
