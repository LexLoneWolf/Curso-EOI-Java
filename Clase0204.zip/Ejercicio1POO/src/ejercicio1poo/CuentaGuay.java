/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1poo;

/**
 *
 * @author Profesor
 */
public class CuentaGuay extends Cuenta{
    
    private String numerocuentaguay;
    private String nombre_cliente;
    
    public CuentaGuay(){
        
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    
    
    public String getNumerocuentaguay() {
        return numerocuentaguay;
    }

    public void setNumerocuentaguay(String numerocuentaguay) {
        this.numerocuentaguay = numerocuentaguay;
    }

    @Override
    public boolean ingreso(double cantidad) {
        if(cantidad>1000){
            this.setSaldo(this.getSaldo()+cantidad);
        }
        else{
            this.setSaldo(1000);
        }
        return true;
    }
    
    public void sacarnombres(){
        System.out.println(this.nombre_cliente);
        System.out.println(super.nombre_cliente);
    }
    
    
    
       
}
